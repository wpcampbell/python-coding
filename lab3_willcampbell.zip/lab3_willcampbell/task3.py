import sys #imports dys module
import math#imports math module
#task 3: promps the user for 2 city names,find the latitude and longitudes for those cities, and then uses
#the great circle function to calulate the distance between them
citypop=open('CityPop.csv') #opens the csv file
outercitydict={} #defines the "outer dictionary" which stores the list of city information

header = citypop.readline().strip().split(",") #reads the csv file

#accesses the data in the csv
for cityinfo in citypop: #stores the city name into a variable 'label' and starts a loop
    
    citylist=(cityinfo.strip().split(",")) #processes each line of the csv by stripping it of new lines and splitting it into a list
    label=citylist[4] #indexes the city name column or 'label' in the csv and stores it in a variable
    innercitydict= dict(zip(header, citylist)) #defines the "inner" dictionary: with the headers as keys and the city info as values
    outercitydict[label]=innercitydict #stores the inner dictionary in the outer dictionary

print("Welcome to the city distance calculator!")#Welcomes the user
print()
#asks the user for a city, checks to see if its in the dictionary and then finds the latitude and longitude of the city
cityone=input("Enter the name of a city: ")
try:
    cityonecheck=outercitydict[cityone]
    latcityone=cityonecheck['latitude']
    longcityone=cityonecheck['longitude']
except:
    print("That entry is not in the dictionary, please start over.")
    sys.exit()
#asks the user for another city, checks to see if its in the dictionary and then finds the latitude and longitude of the  city
citytwo=input("Enter the name of another city: ")
try:
    citytwocheck=outercitydict[citytwo]
    latcitytwo=citytwocheck['latitude']
    longcitytwo=citytwocheck['longitude']
except:
    print("That entry is not in the dictionary, please start over.")
    sys.exit()




#distance calculator 

latcityone_rads=math.radians(float(latcityone)) #converts the first latitude from degrees to radians


longcityone_rads= math.radians(float(longcityone))#converts the first longitude from degrees to radians


latcitytwo_rads= math.radians(float(latcitytwo))#converts the second latitude from degrees to radians


longcitytwo_rads= math.radians(float(longcitytwo))#converts the second longitude from degrees to radians
#calculates the angular distance between the two places given. Equation broken down into multiple variables in order to solve.

e= (longcityone_rads-longcitytwo_rads)
f= (math.cos(e))
g=(math.cos(latcityone_rads))*math.cos(latcitytwo_rads)
h=(math.sin(latcityone_rads))*math.sin(latcitytwo_rads)
i=(math.acos(h+g*f))
j=i*6300

print("The distance between",cityone,"and",citytwo, "is",j,"km. WOW!")