import sys #imports the 'sys' module
#task 2: prompt the user for a city('label') and a year('yrxxxx') without the program bombing



citypop=open('CityPop.csv') #opens the csv file
outercitydict={} #defines the "outer dictionary" which stores the list of city information

header = citypop.readline().strip().split(",") #reads the csv file

#accesses the data in the csv
for cityinfo in citypop: #stores the city name into a variable 'label' and starts a loop
    
    citylist=(cityinfo.strip().split(",")) #processes each line of the csv by stripping it of new lines and splitting it into a list
    label=citylist[4] #indexes the city name column or 'label' in the csv and stores it in a variable
    innercitydict= dict(zip(header, citylist)) #defines the "inner" dictionary: with the headers as keys and the city info as values
    outercitydict[label]=innercitydict #stores the inner dictionary in the outer dictionary
    
    #example of how to call things from a dictionary: "find the longitude of Manila"
#maniladict=outercitydict['Manila']
#dictdict=maniladict['longitude']





print("Welcome to the city-population dictionary!") #welcomes the user
print() 
cityinput=input("Please enter the name of a city such as Manila: ") #asks the user for the name of a city  

#checks to see if the user input is actually in the dictionary
try:
    citydictsearch= outercitydict[cityinput]
except:
    print("That entry is not in the dictionary, please start over.")
    sys.exit()



yearinput=input("Please enter a year such as 1970: ") #asks the user for a year
cityinputfinal= 'yr'+yearinput #adds 'yr' to the end of the user input so the dictionary can read it

#checks to see if the user input is actually in the dictionary
try:
    yeardictsearch=citydictsearch[cityinputfinal]
except:
    print("That entry is not in the dictionary, please start over.")
    sys.exit()


#summary
print("The population of ",cityinput,"in",yearinput,"was",yeardictsearch,"million.")

