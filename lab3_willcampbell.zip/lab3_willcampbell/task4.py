import sys #imports the 'sys' module
# task 4: prompts the user for two years, finds the population change between those years, and output the results 
#to a new csv file with the fields of " id, city,and population_change. Include the field names in the first line of the file
try:
    citypop=open('CityPop.csv') #opens the csv file
except:
    sys.exit()


outercitydict={} #defines the "outer dictionary" which stores the list of city information

header = citypop.readline().strip().split(",") #reads the csv file


#accesses the data in the csv
for cityinfo in citypop: #stores the city name into a variable 'label' and starts a loop
    
    citylist=(cityinfo.strip().split(",")) #processes each line of the csv by stripping it of new lines and splitting it into a list
    label=citylist[4] #indexes the city name column or 'label' in the csv and stores it in a variable
    innercitydict= dict(zip(header, citylist)) #defines the "inner" dictionary: with the headers as keys and the city info as values
    outercitydict[label]=innercitydict #stores the inner dictionary in the outer dictionary

print(citypop)
print("Welcome to the city population change calculator") #welcomes the user
print()

yearone=input("Please enter a year: ") #asks the user to enter a year

yearonemod= 'yr'+yearone #adds 'yr' to the user input

#searches for the user input in list of headers, and if its not, the program ends
if yearonemod not in header:
    print("Sorry, that year is not in the dictionary. Please start over.")
    sys.exit()

yeartwo=input("Please input another year: ")#asks the user to enter another year

yeartwomod= 'yr'+yeartwo #adds 'yr' to the user input
#searches for the user input in list of headers, and if its not, the program ends
if yeartwomod not in header:
    print("Sorry, that year is not in the dictionary. Please start over.")
    sys.exit()


#loop to find info for id, city and population change
for citystats in outercitydict: 
    csvchange= outercitydict[citystats]
    idline=print(csvchange['id'])
    labelline=print(csvchange['label'])
    year1=print(csvchange[yearonemod])
    year2=print(csvchange[yeartwomod])
#defines the string to be printed
a= ['id'+ ',' + 'city' + ',' + 'pop_change\n''idline + ',' + labelline + ',' + year2-year1']
#writes CityPopChg
try:
    citypopchg = open('CityPopChg.csv','w')
    citypopchg.writelines(a)
    citypopchg.close()

except:
    sys.exit()

#couldnt figure out how to write the second part of the string properly...







