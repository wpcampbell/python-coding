#task 1: read the contents of csv file and store it in a container of containers
citypop=open('CityPop.csv') #opens the csv file

outercitydict={} #defines the "outer dictionary" which stores the list of city information

header = citypop.readline().strip().split(",") #reads the csv file

#accesses the data in the csv
for cityinfo in citypop: #stores the city name into a variable 'label' and starts a loop
    
    citylist=(cityinfo.strip().split(",")) #processes each line of the csv by stripping it of new lines and splitting it into a list
    label=citylist[4] #indexes the city name column or 'label' in the csv and stores it in a variable
    innercitydict= dict(zip(header, citylist)) #defines the "inner" dictionary: with the headers as keys and the city info as values
    outercitydict[label]=innercitydict #stores the inner dictionary in the outer dictionary
    #example of how to call things from a dictionary: "find the longitude of Manilas"
#maniladict=outercitydict['Manila']
#dictdict=maniladict['longitude']
#print(dictdict)  
 

      
    

    

   
